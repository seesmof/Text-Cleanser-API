**And He has said to me, “My grace is sufficient for you, for power is perfected in weakness.” Most gladly, therefore, I will rather boast about my weaknesses, so that the power of Christ may dwell in me.**
– [2 Corinthians 12:9 NASB](https://www.biblegateway.com/passage/?search=2+Corinthians+12%3A9&version=NASB,KJV)

**For by grace you have been saved through faith; and this _is_ not of yourselves, _it is_ the gift of God; not a result of works, so that no one may boast.**
– [Ephesians 2:8-9 NASB](https://www.biblegateway.com/passage/?search=Ephesians+2%3A8-9&version=NASB,KJV)

**For sin shall not be master over you, for you are not under the Law but under grace.**
– [Romans 6:14 NASB](https://www.biblegateway.com/passage/?search=Romans+6%3A14&version=NASB,KJV)

cleans the input text, be it from a file or just a string, from html, usfm and excessive spacing